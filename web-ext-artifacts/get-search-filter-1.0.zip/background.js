var filter = ''
var response = ''
var responseFilter = null

browser.runtime.onMessage.addListener(async data => {
  if (data.type === 'getFilter') {
    // console.log(JSON.parse(response))
    // await browser.runtime.sendMessage({type: 'filter', filter: response})
    await saveXl()
  }
})

function filterResponse(details) {
  filter = JSON.parse(new TextDecoder().decode(new Uint8Array(details.requestBody.raw[0].bytes)))
  responseFilter = browser.webRequest.filterResponseData(details.requestId)
  let decoder = new TextDecoder("utf-8")
  responseFilter.ondata = event => {
    response += decoder.decode(event.data, {stream: true})
    responseFilter.write(event.data)
  }
}

browser.webRequest.onBeforeRequest.addListener(
  filterResponse,
  {urls: ["https://old.zakupki.mos.ru/api/Cssp/Sku/PostQuery"]},
  ["requestBody", "blocking"]
)

browser.webRequest.onCompleted.addListener(
  () => {
    if (responseFilter !== null) {
      responseFilter.disconnect()
      responseFilter = null
    }
  },
  {urls: ["https://old.zakupki.mos.ru/api/Cssp/Sku/PostQuery"]},
)

async function saveXl() {
  // console.log('background ready to save xl')
  const wb = XLSX.utils.book_new()
  const { items } = JSON.parse(response)
  const rowsPromises = items.map(async item => {
    const entity = await getItemEntity(item.id)
    return {
      'Ключевое слово': filter.filter.keyword,
      'Наименование': item.name,
      'ID СТЕ': item.id,
      ...entity.price,
      'Количество предложений': item.offersCount,
      'КПГЗ': `${item.productionCode} - ${item.productionDirectoryName.toUpperCase()}`,
      'Востребованная продукция': item.isDemanded,
      ...entity.characteristics
    }
  })
  const rows = await Promise.all(rowsPromises)
  // console.log(rows)
  const ws = XLSX.utils.json_to_sheet(rows)
  XLSX.utils.book_append_sheet(wb, ws, filter.filter.keyword)
  XLSX.writeFile(wb, `parsed_${filter.filter.keyword}.xlsx`)
}

async function getItemEntity(id) {
  const res = await fetch(`https://old.zakupki.mos.ru/api/Cssp/Sku/GetEntity?id=${id}`)
  // const fetchTimer = setInterval(async () => {
  //   if (res.status === 200) {
  //     clearInterval(fetchTimer)
  //   }
  // }, 1000)
  const entity = await res.json()
  const { minPrice, maxPrice, medianPrice, skuCharacteristics } = entity
  const price = {
    'Минимальная цена': minPrice,
    'Максимальная цена': maxPrice,
    'Средняя цена': medianPrice,
  }
  let characteristics = {}
  skuCharacteristics.map(item => {
    if (item.characteristicValueBoolValue !== null) {
      var characteristicValueBoolValue = item.characteristicValueBoolValue ? "Да" : "Нет"
    }
    let charName = item.productCharacteristicValue.productCharacteristicName
    let charValue = characteristicValueBoolValue || item.characteristicValueDateTimeValue || item.characteristicValueDecimalValue || item.characteristicValueIntValue || item.characteristicValueStringValue
    characteristics = {
      ...characteristics,
      [charName]: charValue
    }
  })

  // console.log(characteristics)
  return { price, characteristics }
}