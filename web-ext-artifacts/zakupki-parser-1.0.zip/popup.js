// const textarea = document.getElementById('filter')
const button = document.getElementById('parsing')

// browser.runtime.onMessage.addListener(async data => {
//   if (data.type === 'filter') {
//     textarea.value = data.filter
//     textarea.select()
//     document.execCommand("copy")
//     // saveXl(data.filter)
//     // await fetchWithFilter(data.filter)
//     // alert('Скопировано в буфер')
//   }
// })

button.addEventListener('click', async () => {
  await browser.runtime.sendMessage({type: 'getFilter'})
})

// async function fetchWithFilter(filter) {
//   const response = await fetch(
//     'https://old.zakupki.mos.ru/api/Cssp/Sku/PostQuery',
//     {
//       method: 'POST',
//       body: JSON.stringify(filter)
//     }
//   )
//   // console.log(response)
// }
